import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        backgroundColor: Colors.white,
        body: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Image(
              image: AssetImage(
                'images/penne-pasta-carbonara-cream-sauce-with-mushroom_1339-81372.jpg',
              ),
            ),
            Container(
              padding: EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'About',
                    style: TextStyle(fontSize: 29, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 19),
                  Text(
                    'White sauce pasta is also called Bechamel sauce pasta. The Bechamel sauce is made from a white roux (butter and flour) and milk and is used as a base for many sauces. It is often considered one of the mother sauces of French cuisine.',
                    style: TextStyle(fontSize: 18),
                  ),
                  SizedBox(height: 19),
                  Text(
                    'Ingredients',
                    style: TextStyle(fontSize: 29, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 23),
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 10),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(
                          width: 75,
                          height: 75,

                          decoration: BoxDecoration(
                            border: Border.all(color: Colors.grey, width: 1),
                            borderRadius: BorderRadius.circular(15),
                          ),
                          child: Image(
                            image: AssetImage('images/pasta.png'),
                            fit: BoxFit.fill,
                          ),
                        ),
                        Container(
                          width: 75,
                          height: 75,

                          decoration: BoxDecoration(
                            border: Border.all(color: Colors.grey, width: 1),
                            borderRadius: BorderRadius.circular(15),
                          ),
                          child: Image(
                            image: AssetImage('images/butter.png'),
                            fit: BoxFit.fill,
                          ),
                        ),
                        Container(
                          width: 75,
                          height: 75,

                          decoration: BoxDecoration(
                            border: Border.all(color: Colors.grey, width: 1),
                            borderRadius: BorderRadius.circular(15),
                          ),
                          child: Image(
                            image: AssetImage('images/garlic.png'),
                            fit: BoxFit.fill,
                          ),
                        ),
                        Container(
                          width: 75,
                          height: 75,

                          decoration: BoxDecoration(
                            border: Border.all(color: Colors.grey, width: 1),
                            borderRadius: BorderRadius.circular(15),
                          ),
                          child: Image(
                            image: AssetImage('images/chicken.png'),
                            fit: BoxFit.fill,
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 20),
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 10),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(
                          width: 75,
                          height: 75,

                          decoration: BoxDecoration(
                            border: Border.all(color: Colors.grey, width: 1),
                            borderRadius: BorderRadius.circular(15),
                          ),
                          child: Image(
                            image: AssetImage('images/pasta.png'),
                            fit: BoxFit.fill,
                          ),
                        ),
                        Container(
                          width: 75,
                          height: 75,

                          decoration: BoxDecoration(
                            border: Border.all(color: Colors.grey, width: 1),
                            borderRadius: BorderRadius.circular(15),
                          ),
                          child: Image(
                            image: AssetImage('images/butter.png'),
                            fit: BoxFit.fill,
                          ),
                        ),
                        Container(
                          width: 75,
                          height: 75,

                          decoration: BoxDecoration(
                            border: Border.all(color: Colors.grey, width: 1),
                            borderRadius: BorderRadius.circular(15),
                          ),
                          child: Image(
                            image: AssetImage('images/garlic.png'),
                            fit: BoxFit.fill,
                          ),
                        ),
                        Container(
                          width: 75,
                          height: 75,

                          decoration: BoxDecoration(
                            border: Border.all(color: Colors.grey, width: 1),
                            borderRadius: BorderRadius.circular(15),
                          ),
                          child: Image(
                            image: AssetImage('images/chicken.png'),
                            fit: BoxFit.fill,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
